<?php

add_theme_support('post-thumbnails');
register_nav_menu('header','Menú principal');